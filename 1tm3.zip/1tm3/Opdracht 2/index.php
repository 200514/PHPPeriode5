<?php

$servername = "localhost";
$dbname     = "boekenarchief";
$username   = "root";
$password   = "root";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
$sql = "SELECT * FROM bibliotheek_leden";
$result = $conn->query($sql);
 
 
class Table {
    private $_rows;
 
    public function construct() {
        $this->_rows = array();
    }
 
    public function append($row) {
        $this->_rows[] = $row;
    }
 
    public function draw() {
        echo '<table border="1">'.PHP_EOL; // Begin van de tabel, border voor de duidelijkheid
 
        foreach($this->_rows as $row) {
            echo '<tr>'.PHP_EOL;
 
            foreach($row->getCells() as $cell) {
                echo '<td>'.$cell->getContent().'</td>'.PHP_EOL;
            }
 
            echo '</tr>'.PHP_EOL;
        }
 
        echo '</table>'.PHP_EOL; 
    }
}
 
class Row {
    private $_cells;
 
    public function construct() {
        $this->_cells = array();
    }
 
    public function append($cell) {
        $this->_cells[] = $cell;
    }
 
    public function getCells() {
        return $this->_cells;
    }
}
 
class Cell {
    private $_content;
 
    public function __construct($content) {
        $this->_content = $content;
    }
 
    public function getContent() {
        return $this->_content;
    }
}
 
$table = new Table();
 
$rowHeader = new Row();
$rowHeader->append(new Cell('user_id'));
$rowHeader->append(new Cell('email'));
$rowHeader->append(new Cell('password'));
$rowHeader->append(new Cell('datetime'));
 
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cellId = new Cell($row['user_id']);
        $cellEmail = new Cell($row['email']);
        $cellPassword = new Cell($row['password']);
        $cellTime = new Cell($row['datetime']);
 
        $rowDynamic = new Row();
        $rowDynamic->append($cellId);
        $rowDynamic->append($cellEmail);
        $rowDynamic->append($cellPassword);
        $rowDynamic->append($cellTime);
 
        $table->append($rowDynamic);
    }
} else {
    echo "0 Results";
}
 
$table->draw();
 
$conn->close();
?>