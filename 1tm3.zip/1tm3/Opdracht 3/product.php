
<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
include('connect.php');
class Product
{
   private $con;
   private $table_name = "product";
   public function __construct($db)
   {
       $this->con = $db;
   }
   public function read()
   {
    $liqry = $this->con->prepare("SELECT id, category_id, name, price, information, active FROM product ");
    if($liqry === false) {
       echo mysqli_error($con);
    } else{
        $liqry->bind_result($id, $category_id, $name, $price, $information, $active);
        if($liqry->execute()){
            $liqry->store_result();
            echo '<table border=1>
                <tr>
                    <td> id </td>
                    <td>category_id </td>
                    <td>name </td>
                    <td>price </td>
                    <td>information </td>
                    <td>active </td>
                    <td>Edit </td>
                    <td>Delete </td>
                    <td>Create </td>
                </tr>';
            while($liqry->fetch()) {
                ?>
                
             <tr>
                <td><?php echo $id ?></td>
                <td><?php echo $category_id ?></td>
                <td><?php echo $name ?></td>
                <td><?php echo $price ?></td>
                <td><?php echo $information ?></td>
                <td><?php echo $active ?></td>
                <td><?php echo '<a href="?crud=edit&id='.$id.'">edit</a><br>'?></td>
                <td><?php echo '<a href="?crud=delete&id='.$id.'">Delete</a><br>'?></td>
                <td><?php echo '<a href="?crud=create">Create</a><br>'?></td>
                 <?php
                }
         }

      }
   }
   public function create(){
      if (isset($_POST['name']) && $_POST['name'] != "") {
          $name = $this->con->real_escape_string($_POST['name']);
          $category_id = $this->con->real_escape_string($_POST['category_id']);
          $price = $this->con->real_escape_string($_POST['price']);
          $information = $this->con->real_escape_string($_POST['information']);
  
          $liqry = $this->con->prepare("INSERT INTO `product` (`name`, category_id, price ,  `information`, `active` ) VALUES (?, ?, ?, ?, 1);");
          if($liqry === false) {
             echo mysqli_error($this->con);
             echo"lukt niet";
          } else{
              $liqry->bind_param('siis',$name,$category_id, $price, $information, );
              if($liqry->execute()){
               header('Location:productToon.php');
              }else{
              echo mysqli_error($this->con);
                  echo"lukt niet";
              }
          }
          $liqry->close();
  
      }
  ?>
  <form action="" method="POST">
  
  name: <input type="text" name="name" value=""><br><br>
  category_id: <input type="number" name="category_id" value=""><br><br>
  price: <input type="number" name="price" value=""><br><br>
  information: <input type="text" name="information" value=""><br><br>
  <input type="submit" name="submit" value="Toevoegen">
  </form><?php
     }


     public function edit($product_id){
      echo $product_id;
          if (isset($_POST['submit']) && $_POST['submit'] != '') {
              $id = $this->con->real_escape_string($_POST['id']);
              $name = $this->con->real_escape_string($_POST['name']);
              $category_id = $this->con->real_escape_string($_POST['category_id']);
              $price = $this->con->real_escape_string($_POST['price']);
              $information = $this->con->real_escape_string($_POST['information']);
              $active = $this->con->real_escape_string($_POST['active']);
              $query1 = $this->con->prepare("UPDATE product SET name = ?, category_id = ?, price = ?, information = ? , active = ? WHERE id = ? LIMIT 1;");
              if ($query1 === false) {
                  echo mysqli_error($this->con);
              }
                          
              $query1->bind_param('siisii',$name, $category_id, $price, $information, $active, $id);
              if ($query1->execute() === false) {
                  echo mysqli_error($this->con);
                  echo "wekt niet1";
                  // echo "name:".$name." desc:".$description." act:".$active." id:".$id;
              } else {
                  header('Location:productToon.php');
              }
              $query1->close();
              return;
                          
          }
      ?>
      
      <form action="" method="POST">
      <?php
             
              $liqry = $this->con->prepare("SELECT id, name, category_id, price, information, active FROM product WHERE id = $product_id LIMIT 1;");
              if($liqry === false) {
                 echo mysqli_error($this->con);
              } else{
                  $liqry->bind_param('i',$id);
                  $liqry->bind_result($id, $name, $category_id, $price, $information, $active);
                  if($liqry->execute()){
                      $liqry->store_result();
                      $liqry->fetch();
                      if($liqry->num_rows == '1'){
                          echo 'id: <input type="text" name="id" value="' . $id . '" ><br>';
                          echo 'name: <input type="text" name="name" value="' . $name . '"><br>';
                          echo 'category_id: <input type="text" name="category_id" value="' . $category_id . '"><br>';
                          echo 'price: <input type="text" name="price" value="' . $price . '"><br>';
                          echo 'information: <input type="text" name="information" value="' . $information . '"><br>';
                          echo 'active: <input type="number" name="active" value="' . $active . '"><br>';
                      }
                  }
              }
              $liqry->close();
      ?>
      <br>
      <input type="submit" name="submit" value="Opslaan">
      </form>
      <?php
  
     }
     public function delete($product_id){
      echo $product_id;
   if (isset($_POST['submit']) && $_POST['submit'] != '') {
       echo "hello";
       $id = $this->con->real_escape_string($_POST['id']);
       $query = $this->con->prepare("DELETE FROM product WHERE id = $product_id;");
       if ($query === false) {
           echo mysqli_error($this->con);
           echo "werkt niet";
       }        
       $query->bind_param('i',$id);
       if ($query->execute() === false) {
           echo mysqli_error($this->con);
           echo "werkt niet";
       } else {
           header('Location:productToon.php');
       }
       $query->close();
                   
   }
?>

<form action="" method="POST">  

       <h2 style="color: red">Are you sure you want to delete this product?</h2><?php

      
      $name = $this->con->real_escape_string($_POST['name']);
      $category_id = $this->con->real_escape_string($_POST['category_id']);
      $price = $this->con->real_escape_string($_POST['price']);
      $information = $this->con->real_escape_string($_POST['information']);
      $active = $this->con->real_escape_string($_POST['active']);
      $id = $this->con->real_escape_string($_POST['id']);


       $liqry = $this->con->prepare("SELECT name, category_id, price, information, active FROM product WHERE id = $product_id; ");
       if($liqry === false) {
          echo mysqli_error($this->con);
       } else{
           $liqry->bind_param('i',$id);
           $liqry->bind_result($name,$category_id, $price, $information, $active);
           if($liqry->execute()){
               $liqry->store_result();
               $liqry->fetch();
               if($liqry->num_rows == '1'){
                   echo '$id: ' . $id . '<br>';
                   echo '<input type="hidden" name="id" value="' . $id . '" />';
                   echo '$name: ' . $name . '<br>';
                   echo '$category_id: ' . $category_id . '<br>';
                   echo '$price: ' . $price . '<br>';
                   echo '$information: ' . $information . '<br>';
                   echo '$active: ' . $active . '<br>';
               }
           }
       $liqry->close();

       ?>
       <br>
       <input type="submit" name="submit" value="Yes, delete!">
       </form>
       <?php
       }

  }
}