<?php
    
    // onderstaand bestand wordt ingeladen
    include('../core/db_connect.php');
    // include('../core/checklogin_admin.php');
?>

<h1>category toevoegen</h1>


<?php



 
 echo "<pre>";
 print_r($_POST);
 echo "</pre>";
    if (isset($_POST['name']) && $_POST['name'] != "") {
        $name = $con->real_escape_string($_POST['name']);
        $information = $con->real_escape_string($_POST['information']);

        $liqry = $con->prepare("INSERT INTO `category` (`name`, `information`, `active` ) VALUES (?, ?, 1);");
        if($liqry === false) {
           echo mysqli_error($con);
           echo"lukt niet";
        } else{
            $liqry->bind_param('ss',$name,$information, );
            if($liqry->execute()){
                echo "hello";
            }else{
                echo mysqli_error($con);
                echo"lukt niet";
            }
        }
        $liqry->close();

    }
?>
<form action="" method="POST">

name: <input type="text" name="name" value=""><br><br>
information: <input type="text" name="information" value=""><br><br>
<input type="submit" name="submit" value="Toevoegen">
</form>



<?php
    include('../core/footer.php');
?>

