<?php
    
    // onderstaand bestand wordt ingeladen
    // include('../core/header.php');
    include('../core/db_connect.php');
    // include('../core/checklogin_admin.php');
?>

<h1>category bewerken</h1>

<?php
echo $id;
    if (isset($_POST['submit']) && $_POST['submit'] != '') {
        $id = $con->real_escape_string($_POST['id']);
        $name = $con->real_escape_string($_POST['name']);
        $information = $con->real_escape_string($_POST['information']);
        $active = $con->real_escape_string($_POST['active']);
        $query1 = $con->prepare("UPDATE category SET name = ?, information = ? , active = ? WHERE id = ? LIMIT 1;");
        if ($query1 === false) {
            echo mysqli_error($con);
        }
                    
        $query1->bind_param('ssii',$name,$information, $active, $id);
        if ($query1->execute() === false) {
            echo mysqli_error($con);
            echo "wekt niet1";
            // echo "name:".$name." desc:".$description." act:".$active." id:".$id;
        } else {
            header('Location:index.php');
        }
        $query1->close();
                    
    }
?>

<form action="" method="POST">
<?php
    if (isset($_GET['id']) && $_GET['id'] != '') {
        $id = $con->real_escape_string($_GET['id']);

        $liqry = $con->prepare("SELECT id, name, information, active FROM category WHERE id = ? LIMIT 1;");
        if($liqry === false) {
           echo mysqli_error($con);
        } else{
            $liqry->bind_param('i',$id);
            $liqry->bind_result($id, $name, $information, $active);
            if($liqry->execute()){
                $liqry->store_result();
                $liqry->fetch();
                if($liqry->num_rows == '1'){
                    echo 'id: <input type="text" name="id" value="' . $id . '" ><br>';
                    echo 'name: <input type="text" name="name" value="' . $name . '"><br>';
                    echo 'information: <input type="text" name="information" value="' . $information . '"><br>';
                    echo 'active: <input type="number" name="active" value="' . $active . '"><br>';
                }
            }
        }
        $liqry->close();

    }
?>
<br>
<input type="submit" name="submit" value="Opslaan">
</form>

<?php
    include('../core/footer.php');
?>