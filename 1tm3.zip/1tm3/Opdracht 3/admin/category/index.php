<?php
  include('../core/db_connect.php');
?>
 
<h1>Product overzicht</h1>
<li><a href="index.php">overzicht van catergory</a></li>
<li><a href="add_category.php">Category toevoegen</a></li>
 
<?php
       $liqry = $con->prepare("SELECT id, name, information, active FROM category ");
       if($liqry === false) {
          echo mysqli_error($con);
       } else{
           $liqry->bind_result($id, $name, $information, $active);
           if($liqry->execute()){
               $liqry->store_result();
               echo '<table border=1>
                <tr>
                    <td> id </td>
                    <td>name </td>
                    <td>information </td>
                    <td>active </td>
                    <td>Edit </td>
                </tr>';
               while($liqry->fetch()) {
                   ?>
                <tr>
                   <td><?php echo $id ?></td>
                   <td><?php echo $name ?></td>
                   <td><?php echo $information ?></td>
                   <td><?php echo $active ?></td>
                   <td><?php echo '<a href="edit_category.php?id='.$id.'">edit</a><br>'?></td>
                    <?php
                   }
 
                //    echo '<a href="edit_category.php?id='.'">edit</a><br>';
               }
           $liqry->close();
       }
 
?>
 
<?php
   include('../core/footer.php');
?>