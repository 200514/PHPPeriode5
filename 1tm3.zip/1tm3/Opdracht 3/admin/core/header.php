<!-- <?php
    //include('core/db_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
<img class="gameshop" src="assets/img/gameshop_logo_2.png" alt="gameshop">
<img class="uil" src="assets/img/robot-uil.png" alt="uil">
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="overzicht.php">overzicht producten</a></li>
        <li><a href="detail.php">detail pagina </a></li>
    </ul>
</nav> -->