<?php

include('product.php');



$con = new Database("localhost","API_","root","root");
$db = $con->getConnection();

$prod = new Product($db);
if (isset($_GET['crud']) && $_GET['crud'] != '') {
    if ($_GET['crud']=="create"){
        $prod->create();

        }   
    if ($_GET['crud']=="edit"){
        echo "vul id in";
        if (isset($_GET['id']) && $_GET['id'] != '') {
            $prod->edit($_GET['id']);

        }

    }
    if ($_GET['crud']=="delete"){
        echo "vul id in";
        if (isset($_GET['id']) && $_GET['id'] != '') {
            $prod->delete($_GET['id']);

        }

    }
    else{
        $prod->read();
    }


} else{
    $prod->read();
}
?>